from tw_stock_ai.db import init_db


if __name__ == "__main__":
    init_db()
    print("database initialized")
